A Pen created at CodePen.io. You can find this one at https://codepen.io/agence-web-coheractio/pen/pEnoA.

 

Jquery UI dialogs can't be closed when you click elsewhere on the page that makes it a problem when you have several dialogs on a single page (you'd expect that opening a dialog widget will automatically close the other opened dialogs) or links or elements that keep you on the same page (e.g. form, ajax refresh, ...).

Agence Web Coheractio (http://www.coheractio.com) has developed a small plugin (1 ko) enabling that important feature.
